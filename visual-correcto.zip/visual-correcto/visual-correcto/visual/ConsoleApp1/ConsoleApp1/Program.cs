﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creamos tres objetos de tipo Nodo
            Nodo nodoA = new Nodo(10);
            Nodo nodoB = new Nodo(20);
            Nodo nodoC = new Nodo(30);

            // Los enlazamos para formar la estructura de datos
            nodoA.Siguiente = nodoB; // El objeto A apunta al objeto B
            nodoB.Siguiente = nodoC; // El objeto B apunta al objeto C

            // Ahora puedes navegar entre ellos usando sus referencias
            Console.WriteLine(nodoA.Valor);                    // Imprime 10
            Console.WriteLine(nodoA.Siguiente.Valor);          // Imprime 20 (el valor de B)
            Console.WriteLine(nodoA.Siguiente.Siguiente.Valor); // Imprime 30 (the valor de C)

        }
    }
}
