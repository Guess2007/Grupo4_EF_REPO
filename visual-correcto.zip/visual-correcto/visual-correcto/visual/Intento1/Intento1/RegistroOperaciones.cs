﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Intento1
{
    public partial class RegistroOperaciones : Form
    {
        ListaS lista1 = new ListaS();
        public RegistroOperaciones()
        {
            InitializeComponent();
            // Carga inicial
            lista1.registrarOperacion(new Operacion("100", "Deposito", 1000m, "Sur"));
            lista1.registrarOperacion(new Operacion("101", "Retiro", 500m, "Norte"));
            lista1.registrarOperacion(new Operacion("102", "Transferencia", 250m, "Central"));
            lista1.registrarOperacion(new Operacion("103", "Deposito", 1500m, "Este"));
            lista1.registrarOperacion(new Operacion("104", "Retiro", 300m, "Sur"));

            lista1.imprimirDGV(dgvOperaciones);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //Botones
        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            //Declaración de variables
            string Codigo;
            string Tipo;
            decimal Monto;
            String Agencia;
            //Entrada de datos
            Codigo = txtCodigo.Text;
            Tipo = cmbTipo.SelectedItem.ToString();
            Monto = decimal.Parse(txtMonto.Text);
            Agencia = cmbAgencia.SelectedItem.ToString();
            //Proceso de calculo
            lista1.registrarOperacion(new Operacion(Codigo, Tipo, Monto, Agencia));
            //Salida de resultados
            lista1.imprimirDGV(dgvOperaciones);

            txtCodigo.Clear();
            cmbTipo.SelectedIndex = -1;
            txtMonto.Clear();
            cmbAgencia.SelectedIndex = -1;

            txtCodigo.Focus();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            if (lista1.inicio == null)
            {
                MessageBox.Show("No hay operaciones pendientes.");
                return;
            }

            lista1.eliminarPrimero();

            lista1.imprimirDGV(dgvOperaciones);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCodigo.Clear();
            cmbTipo.SelectedIndex = -1;
            txtMonto.Clear();
            cmbAgencia.SelectedIndex = -1;
            txtCodigo.Focus();
        }

        private void cmbTipo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbAgencia_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
