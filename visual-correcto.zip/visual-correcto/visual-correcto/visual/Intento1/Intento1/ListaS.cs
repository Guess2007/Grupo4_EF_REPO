﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Intento1
{
    internal class ListaS
    {
        public Nodo inicio, final;

        public ListaS()
        {
            inicio = final = null;
        }

        public void registrarOperacion(Operacion dato)
        {
            //Nodo huerfano
            Nodo aux = new Nodo(dato);

            if (inicio == null)
            {
                inicio = final = aux;
            }
            else
            {
                final.siguiente = aux;
                final = aux;
            }
        }

        public void imprimirDGV(DataGridView dgv)
        {
            dgv.Rows.Clear();

            Nodo p = inicio;

            while (p != null)
            {
                dgv.Rows.Add(p.dato.CodigoOperacion,
                    p.dato.Tipo,
                    p.dato.Monto,
                    p.dato.Agencia);
                p = p.siguiente; //permite recorrer secuencialmente la lista
            }
        }

        public void eliminarPrimero()
        {
            if (inicio != null)
            {
                inicio = inicio.siguiente;

                if (inicio == null)
                {
                    final = null;
                }
            }
        }

    }
}
