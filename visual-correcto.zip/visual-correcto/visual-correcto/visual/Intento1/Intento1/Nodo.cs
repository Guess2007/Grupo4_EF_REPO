﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intento1
{
    internal class Nodo
    {
        public Operacion dato;
        public Nodo siguiente;

        public Nodo(Operacion valor)
        {
            dato = valor;
            siguiente = null;
        }

    }
}
